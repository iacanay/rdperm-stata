{\rtf1\ansi\ansicpg1252\cocoartf1038\cocoasubrtf360
{\fonttbl\f0\fmodern\fcharset0 Courier;}
{\colortbl;\red255\green255\blue255;}
\paperw11900\paperh16840\margl1440\margr1440\vieww11180\viewh8780\viewkind0
\deftab720
\pard\pardeftab720\ql\qnatural

\f0\fs24 \cf0 This is a README file for `rdperm'.\
------------------------------------------------------------------------------\
\
SUBJECT:    rdperm\
\
AUTHOR(S):  Ivan A. Canay\
            Northwestern University\
\
            Vishal Kamat\
            Northwestern University\
\
SUPPORT:    <iacanay@northwestern.edu, v.kamat@u.northwestern.edu>\
\
NOTES:      Download files in working directory, and run the following command    \
            before implementing:\
 \
            . capture program drop rdperm\
\
            The file `rdperm_example' illustrates the implementation for the \
            results in Canay and Kamat (2016) on the dataset from Lee (2008). \
            The dataset is contained in `table_two_final.dta'. For further help \
            type:\
\
            . help rdperm\
\
FILES:\
\
rdperm.ado\
rdperm.hlp\
rdperm_example.do\
table_two_final.dta}